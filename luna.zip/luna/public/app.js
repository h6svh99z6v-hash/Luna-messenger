(() => {
'use strict';

const $ = (s) => document.querySelector(s);

const state = {
  token: localStorage.getItem('luna_token') || '',
  me: null,
  chats: [],            // [{ user, last, unread }]
  users: new Map(),     // id -> публичный профиль
  msgs: new Map(),      // id собеседника -> массив сообщений
  more: new Map(),      // id собеседника -> есть ли ещё старые сообщения
  online: new Set(),
  typing: new Map(),    // id -> таймер
  active: null,         // id открытого чата
  ws: null,
  wsTimer: null,
  ice: [{ urls: 'stun:stun.l.google.com:19302' }],
  call: null,
  incoming: null,
};

/* ───────── Утилиты ───────── */
function h(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  for (const k of kids.flat()) if (k != null) e.append(k.nodeType ? k : document.createTextNode(String(k)));
  return e;
}
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast.t);
  toast.t = setTimeout(() => (t.hidden = true), 3500);
}
const COLORS = ['#e17076', '#e59a5b', '#a695e7', '#6fbb5b', '#4fb5b9', '#5b9bd5', '#e26fa5', '#c9a227'];
function setAvatar(el, user) {
  const name = (user.name || user.username || '?').trim();
  el.textContent = name.split(/\s+/).slice(0, 2).map((w) => [...w][0] || '').join('').toUpperCase() || '?';
  el.style.background = COLORS[user.id % COLORS.length];
}
const fmtTime = (t) => new Date(t).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
function fmtDay(t) {
  const d = new Date(t), n = new Date();
  const start = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((start(n) - start(d)) / 864e5);
  if (diff === 0) return 'Сегодня';
  if (diff === 1) return 'Вчера';
  return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: d.getFullYear() !== n.getFullYear() ? 'numeric' : undefined });
}
function fmtListTime(t) {
  const d = new Date(t);
  return d.toDateString() === new Date().toDateString() ? fmtTime(t) : d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}
function statusText(u) {
  if (state.typing.has(u.id)) return 'печатает…';
  if (state.online.has(u.id)) return 'в сети';
  if (!u.last_seen) return 'был(а) давно';
  const m = Math.floor((Date.now() - u.last_seen) / 60000);
  if (m < 1) return 'был(а) только что';
  if (m < 60) return `был(а) ${m} мин. назад`;
  const d = new Date(u.last_seen);
  return d.toDateString() === new Date().toDateString()
    ? 'был(а) сегодня в ' + fmtTime(u.last_seen)
    : 'был(а) ' + d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}

async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch { /* пустой ответ */ }
  if (res.status === 401 && state.token) {
    logoutLocal();
    throw new Error('Сессия истекла. Войдите снова');
  }
  if (!res.ok) throw new Error((data && data.error) || 'Ошибка сервера');
  return data;
}

/* ───────── Вход ───────── */
let authStep = 'email';
let pendingEmail = '';

function goStep(step) {
  authStep = step;
  $('#step-email').hidden = step !== 'email';
  $('#step-code').hidden = step !== 'code';
  $('#step-profile').hidden = step !== 'profile';
  $('#auth-back').hidden = step !== 'code';
  $('#auth-error').textContent = '';
  const hint = {
    email: 'Введите почту — пришлём код для входа',
    code: `Мы отправили 6-значный код на ${pendingEmail}`,
    profile: 'Последний шаг: как вас зовут и как вас найти друзьям',
  }[step];
  $('#auth-hint').textContent = hint;
  $('#auth-submit').textContent = { email: 'Получить код', code: 'Войти', profile: 'Готово' }[step];
  const focus = { email: '#email', code: '#code', profile: '#name' }[step];
  setTimeout(() => $(focus).focus(), 0);
}
function showAuth() {
  $('#app').hidden = true;
  $('#auth').hidden = false;
  goStep('email');
}

$('#auth-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = $('#auth-error');
  const btn = $('#auth-submit');
  err.textContent = '';
  btn.disabled = true;
  try {
    if (authStep === 'email') {
      const email = $('#email').value.trim().toLowerCase();
      if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error('Введите корректную почту');
      await api('/auth/request', { method: 'POST', body: { email } });
      pendingEmail = email;
      goStep('code');
    } else if (authStep === 'code') {
      const code = $('#code').value.trim();
      if (!/^\d{6}$/.test(code)) throw new Error('Введите 6-значный код из письма');
      const r = await api('/auth/verify', { method: 'POST', body: { email: pendingEmail, code } });
      state.token = r.token;
      localStorage.setItem('luna_token', r.token);
      state.me = r.user;
      if (r.user.username) start(); else goStep('profile');
    } else {
      state.me = await api('/profile', { method: 'POST', body: { name: $('#name').value, username: $('#username').value } });
      start();
    }
  } catch (ex) {
    err.textContent = ex.message;
  } finally {
    btn.disabled = false;
  }
});
$('#auth-back').addEventListener('click', () => goStep('email'));

function logoutLocal() {
  localStorage.removeItem('luna_token');
  state.token = '';
  try { state.ws && state.ws.close(); } catch { /* ok */ }
  location.reload();
}
$('#logout').addEventListener('click', async () => {
  try { await api('/auth/logout', { method: 'POST' }); } catch { /* ok */ }
  logoutLocal();
});

/* ───────── Старт ───────── */
async function boot() {
  if (!state.token) return showAuth();
  try {
    state.me = await api('/me');
  } catch {
    return showAuth();
  }
  if (!state.me.username) {
    showAuth();
    goStep('profile');
    return;
  }
  start();
}

async function start() {
  $('#auth').hidden = true;
  $('#app').hidden = false;
  $('#me-name').textContent = state.me.name;
  $('#me-user').textContent = '@' + state.me.username;
  setAvatar($('#me-avatar'), state.me);
  $('#notif').hidden = !('Notification' in window) || Notification.permission !== 'default';
  api('/config').then((c) => { if (c.iceServers) state.ice = c.iceServers; }).catch(() => {});
  try { await loadChats(); } catch (e) { toast(e.message); }
  connectWS();
}

/* ───────── Список чатов и поиск ───────── */
let searchResults = null;
let searchSeq = 0;
let searchTimer;

async function loadChats() {
  const rows = await api('/chats');
  state.chats = rows.map((r) => ({ user: r.user, last: r.last, unread: r.unread }));
  for (const r of rows) {
    state.users.set(r.user.id, r.user);
    if (r.online) state.online.add(r.user.id); else state.online.delete(r.user.id);
  }
  renderList();
}

function row(user, sub, time, unread) {
  const av = h('div', { class: 'avatar' });
  setAvatar(av, user);
  if (state.online.has(user.id)) av.classList.add('online');
  return h('button', { class: 'row' + (state.active === user.id ? ' active' : ''), onclick: () => openChat(user.id) },
    av,
    h('div', { class: 'row-body' },
      h('div', { class: 'row-top' }, h('b', {}, user.name), h('span', { class: 'muted small' }, time || '')),
      h('div', { class: 'row-bot' },
        h('span', { class: 'muted ellipsis' }, sub || ''),
        unread ? h('span', { class: 'badge' }, String(unread)) : null)));
}

function renderList() {
  const list = $('#list');
  list.replaceChildren();
  if (searchResults) {
    if (!searchResults.length) list.append(h('div', { class: 'hint' }, 'Никого не нашли. Проверьте @имя пользователя.'));
    for (const u of searchResults) list.append(row(u, '@' + u.username, '', 0));
  } else if (!state.chats.length) {
    list.append(h('div', { class: 'hint' }, 'Пока нет чатов. Введите @имя друга в поиске, чтобы начать переписку.'));
  } else {
    for (const c of state.chats) {
      const sub = c.last ? (c.last.from_id === state.me.id ? 'Вы: ' : '') + c.last.text : '';
      list.append(row(c.user, sub, c.last && fmtListTime(c.last.created_at), c.unread));
    }
  }
  const n = state.chats.reduce((s, c) => s + c.unread, 0);
  document.title = (n ? `(${n}) ` : '') + 'Луна';
}

$('#search').addEventListener('input', () => {
  clearTimeout(searchTimer);
  const q = $('#search').value.trim().replace(/^@/, '');
  if (q.length < 2) {
    searchSeq++;
    searchResults = null;
    renderList();
    return;
  }
  searchTimer = setTimeout(async () => {
    const seq = ++searchSeq;
    try {
      const r = await api('/search?q=' + encodeURIComponent(q));
      if (seq !== searchSeq) return;
      r.forEach((u) => state.users.set(u.id, u));
      searchResults = r;
      renderList();
    } catch { /* ok */ }
  }, 250);
});

$('#menu-btn').addEventListener('click', (e) => {
  e.stopPropagation();
  $('#menu').hidden = !$('#menu').hidden;
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('#menu')) $('#menu').hidden = true;
});
$('#notif').addEventListener('click', async () => {
  const p = await Notification.requestPermission();
  $('#notif').hidden = p !== 'default';
  $('#menu').hidden = true;
});

/* ───────── Открытый чат ───────── */
async function openChat(id) {
  if (searchResults) {
    $('#search').value = '';
    searchResults = null;
  }
  state.active = id;
  $('#app').classList.add('chat-open');
  $('#empty').hidden = true;
  $('#chat-view').hidden = false;
  $('#msgs').replaceChildren();
  updateHead();
  renderList();
  try {
    const r = await api('/messages/' + id);
    if (state.active !== id) return;
    state.users.set(id, r.peer);
    if (r.online) state.online.add(id); else state.online.delete(id);
    state.msgs.set(id, r.messages);
    state.more.set(id, r.messages.length === 50);
    updateHead();
    renderMessages(true);
    markRead(id);
    if (!matchMedia('(pointer: coarse)').matches) $('#text').focus();
  } catch (e) {
    toast(e.message);
  }
}

$('#back').addEventListener('click', () => {
  state.active = null;
  $('#app').classList.remove('chat-open');
  renderList();
});

function updateHead() {
  const u = state.users.get(state.active);
  if (!u) return;
  $('#peer-name').textContent = u.name;
  setAvatar($('#peer-avatar'), u);
  const st = $('#peer-status');
  st.textContent = statusText(u);
  st.classList.toggle('live', state.online.has(u.id) || state.typing.has(u.id));
}

function renderMessages(stick) {
  const box = $('#msgs');
  const list = state.msgs.get(state.active) || [];
  const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
  box.replaceChildren();
  if (state.more.get(state.active)) box.append(h('button', { class: 'more', onclick: loadOlder }, 'Показать ранее'));
  let day = '';
  for (const m of list) {
    const d = fmtDay(m.created_at);
    if (d !== day) {
      day = d;
      box.append(h('div', { class: 'day' }, d));
    }
    const mine = m.from_id === state.me.id;
    box.append(h('div', { class: 'msg ' + (mine ? 'out' : 'in') },
      h('div', { class: 'bubble' },
        m.text,
        h('span', { class: 'meta' }, fmtTime(m.created_at),
          mine ? h('span', { class: 'ticks' + (m.read_at ? ' read' : '') }, m.read_at ? '✓✓' : '✓') : null))));
  }
  if (stick || nearBottom) box.scrollTop = box.scrollHeight;
}

function loadOlder() {
  const id = state.active;
  const arr = state.msgs.get(id);
  if (!arr || !arr.length) return;
  const box = $('#msgs');
  const prev = box.scrollHeight;
  api(`/messages/${id}?before=${arr[0].id}`).then((r) => {
    if (state.active !== id) return;
    state.msgs.set(id, [...r.messages, ...arr]);
    state.more.set(id, r.messages.length === 50);
    renderMessages(false);
    box.scrollTop = box.scrollHeight - prev;
  }).catch((e) => toast(e.message));
}

function markRead(peer) {
  const c = state.chats.find((x) => x.user.id === peer);
  if (c && c.unread) {
    c.unread = 0;
    renderList();
  }
  api('/read/' + peer, { method: 'POST' }).catch(() => {});
}

function addMessage(peer, m) {
  const arr = state.msgs.get(peer);
  if (arr && !arr.some((x) => x.id === m.id)) {
    arr.push(m);
    if (state.active === peer) renderMessages(m.from_id === state.me.id);
  }
  // обновляем список чатов
  let c = state.chats.find((x) => x.user.id === peer);
  if (c && c.last && c.last.id === m.id) return;
  if (!c) {
    const u = state.users.get(peer);
    if (!u) { loadChats().catch(() => {}); return; }
    c = { user: u, last: m, unread: 0 };
    state.chats.unshift(c);
  } else {
    c.last = m;
    state.chats = [c, ...state.chats.filter((x) => x !== c)];
  }
  if (m.from_id !== state.me.id) {
    if (state.active === peer && !document.hidden) markRead(peer);
    else c.unread++;
  }
  renderList();
}

function notify(user, text) {
  if (!document.hidden || !('Notification' in window) || Notification.permission !== 'granted') return;
  try {
    const n = new Notification(user.name, { body: text.slice(0, 120), tag: 'luna-' + user.id });
    n.onclick = () => { window.focus(); openChat(user.id); n.close(); };
  } catch { /* ok */ }
}

/* — отправка — */
const ta = $('#text');
function autosize() {
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, 140) + 'px';
}
async function sendMessage() {
  const text = ta.value.trim();
  const peer = state.active;
  if (!text || peer == null) return;
  ta.value = '';
  autosize();
  try {
    const m = await api('/messages/' + peer, { method: 'POST', body: { text } });
    addMessage(peer, m);
  } catch (e) {
    if (!ta.value) ta.value = text;
    autosize();
    toast(e.message);
  }
}
$('#composer').addEventListener('submit', (e) => { e.preventDefault(); sendMessage(); });
ta.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && !matchMedia('(pointer: coarse)').matches) {
    e.preventDefault();
    sendMessage();
  }
});
let lastTyping = 0;
ta.addEventListener('input', () => {
  autosize();
  if (state.active != null && Date.now() - lastTyping > 3000) {
    lastTyping = Date.now();
    wsSend({ type: 'typing', to: state.active });
  }
});
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && state.active != null) markRead(state.active);
});

/* ───────── WebSocket ───────── */
function wsSend(obj) {
  if (state.ws && state.ws.readyState === 1) {
    state.ws.send(JSON.stringify(obj));
    return true;
  }
  return false;
}

function connectWS() {
  if (!state.token) return;
  const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`);
  state.ws = ws;
  ws.onopen = () => ws.send(JSON.stringify({ type: 'auth', token: state.token }));
  ws.onmessage = (ev) => {
    let m;
    try { m = JSON.parse(ev.data); } catch { return; }
    onWS(m);
  };
  ws.onclose = (ev) => {
    if (state.ws === ws) state.ws = null;
    if (!state.token) return;
    if (ev.code === 4003) return logoutLocal();
    clearTimeout(state.wsTimer);
    state.wsTimer = setTimeout(connectWS, 2000);
  };
}

function onWS(m) {
  switch (m.type) {
    case 'ready': {
      state.online = new Set(m.online);
      loadChats().catch(() => {});
      if (state.active != null) {
        const id = state.active;
        api('/messages/' + id).then((r) => {
          if (state.active !== id) return;
          state.msgs.set(id, r.messages);
          renderMessages(false);
          markRead(id);
        }).catch(() => {});
      }
      break;
    }
    case 'presence': {
      if (m.online) state.online.add(m.userId); else state.online.delete(m.userId);
      const u = state.users.get(m.userId);
      if (u && m.last_seen) u.last_seen = m.last_seen;
      if (m.userId === state.active) updateHead();
      renderList();
      break;
    }
    case 'message': {
      if (m.from) state.users.set(m.from.id, m.from);
      const peer = m.message.from_id === state.me.id ? m.message.to_id : m.message.from_id;
      addMessage(peer, m.message);
      if (m.message.from_id !== state.me.id) {
        const u = state.users.get(peer);
        if (u) notify(u, m.message.text);
      }
      break;
    }
    case 'read': {
      const arr = state.msgs.get(m.by);
      if (arr) {
        for (const x of arr) if (x.from_id === state.me.id && !x.read_at) x.read_at = m.at;
        if (state.active === m.by) renderMessages(false);
      }
      break;
    }
    case 'typing': {
      clearTimeout(state.typing.get(m.from));
      state.typing.set(m.from, setTimeout(() => {
        state.typing.delete(m.from);
        if (state.active === m.from) updateHead();
      }, 4000));
      if (state.active === m.from) updateHead();
      break;
    }
    case 'call':
      onCallSignal(m);
      break;
    default:
  }
}

/* ───────── Звонки (WebRTC) ───────── */
let ringCtx = null;
let ringTimer = null;
function ring(on) {
  clearInterval(ringTimer);
  ringTimer = null;
  if (!on) return;
  try { ringCtx = ringCtx || new (window.AudioContext || window.webkitAudioContext)(); ringCtx.resume && ringCtx.resume(); } catch { return; }
  const beep = () => {
    const o = ringCtx.createOscillator();
    const g = ringCtx.createGain();
    o.type = 'sine';
    o.frequency.value = 440;
    g.gain.value = 0.08;
    o.connect(g);
    g.connect(ringCtx.destination);
    o.start();
    o.stop(ringCtx.currentTime + 0.4);
    if (navigator.vibrate) navigator.vibrate(300);
  };
  beep();
  ringTimer = setInterval(beep, 1600);
}

async function getMedia(wantVideo) {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error('nomedia');
  const audio = { echoCancellation: true, noiseSuppression: true };
  if (wantVideo) {
    try { return await navigator.mediaDevices.getUserMedia({ audio, video: { facingMode: 'user' } }); } catch { /* пробуем только звук */ }
  }
  return navigator.mediaDevices.getUserMedia({ audio, video: false });
}

function showCallUI() {
  const c = state.call;
  const u = state.users.get(c.peerId);
  const box = $('#call');
  box.hidden = false;
  $('#call-name').textContent = u ? u.name : '';
  if (u) setAvatar($('#call-avatar'), u);
  $('#local').srcObject = c.localStream;
  box.classList.toggle('local-on', c.localStream.getVideoTracks().length > 0);
  $('#btn-mute').classList.remove('off');
  $('#btn-cam').classList.remove('off');
  setCallStatus(c.role === 'caller' ? 'Вызываем…' : 'Соединение…');
}
function setCallStatus(t) { $('#call-status').textContent = t; }

let callClock = null;
function startClock() {
  clearInterval(callClock);
  const t0 = Date.now();
  const tick = () => {
    const s = Math.floor((Date.now() - t0) / 1000);
    setCallStatus(`${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`);
  };
  tick();
  callClock = setInterval(tick, 1000);
}

function makePC() {
  const c = state.call;
  const pc = new RTCPeerConnection({ iceServers: state.ice });
  c.pc = pc;
  c.localStream.getTracks().forEach((t) => pc.addTrack(t, c.localStream));
  pc.onicecandidate = (e) => {
    if (e.candidate) wsSend({ type: 'call', kind: 'ice', callId: c.id, data: e.candidate.toJSON() });
  };
  pc.ontrack = (e) => {
    $('#remote').srcObject = e.streams[0];
    $('#call').classList.toggle('has-video', e.streams[0].getVideoTracks().length > 0);
    e.track.onunmute = () => $('#call').classList.toggle('has-video', e.streams[0].getVideoTracks().length > 0);
  };
  pc.onconnectionstatechange = () => {
    if (state.call !== c) return;
    if (pc.connectionState === 'connected') {
      c.phase = 'active';
      startClock();
    } else if (pc.connectionState === 'failed') {
      hangup('Не удалось соединиться. Попробуйте ещё раз');
    } else if (pc.connectionState === 'disconnected') {
      setCallStatus('Связь пропала…');
      setTimeout(() => {
        if (state.call === c && pc.connectionState === 'disconnected') hangup('Связь потеряна');
      }, 8000);
    }
  };
  return pc;
}

async function addIce(cand) {
  const c = state.call;
  if (!c || !c.pc) return;
  if (c.pc.remoteDescription) {
    try { await c.pc.addIceCandidate(cand); } catch { /* ok */ }
  } else {
    c.pending.push(cand);
  }
}
async function flushIce() {
  const c = state.call;
  while (c && c.pending.length) {
    try { await c.pc.addIceCandidate(c.pending.shift()); } catch { /* ok */ }
  }
}

function endCallLocal(msg) {
  const c = state.call;
  clearInterval(callClock);
  ring(false);
  if (c) {
    clearTimeout(c.ringTimer);
    try { c.pc && c.pc.close(); } catch { /* ok */ }
    c.localStream.getTracks().forEach((t) => t.stop());
  }
  state.call = null;
  $('#call').hidden = true;
  $('#call').classList.remove('has-video', 'local-on');
  $('#remote').srcObject = null;
  $('#local').srcObject = null;
  if (msg) toast(msg);
}
function hangup(msg) {
  const c = state.call;
  if (c) wsSend({ type: 'call', kind: 'end', callId: c.id });
  endCallLocal(msg || 'Звонок завершён');
}

async function startCall(video) {
  if (state.call || state.incoming) return toast('Вы уже в звонке');
  const peerId = state.active;
  if (peerId == null) return;
  if (!state.ws || state.ws.readyState !== 1) return toast('Нет соединения с сервером');
  let stream;
  try {
    stream = await getMedia(video);
  } catch {
    return toast('Нет доступа к микрофону' + (video ? ' или камере' : '') + '. Разрешите его в настройках браузера');
  }
  const id = crypto.randomUUID();
  state.call = { id, peerId, role: 'caller', localStream: stream, pending: [], phase: 'ringing', pc: null };
  showCallUI();
  wsSend({ type: 'call', kind: 'invite', callId: id, to: peerId, video: stream.getVideoTracks().length > 0 });
  state.call.ringTimer = setTimeout(() => {
    if (state.call && state.call.id === id && state.call.phase === 'ringing') hangup('Нет ответа');
  }, 45000);
}

function showIncoming(inc) {
  state.incoming = inc;
  state.users.set(inc.from.id, inc.from);
  setAvatar($('#in-avatar'), inc.from);
  $('#in-name').textContent = inc.from.name;
  $('#in-kind').textContent = inc.video ? 'Входящий видеозвонок' : 'Входящий звонок';
  $('#incoming').hidden = false;
  ring(true);
  if (document.hidden && 'Notification' in window && Notification.permission === 'granted') {
    try { new Notification(inc.from.name, { body: 'Входящий звонок', tag: 'luna-call' }); } catch { /* ok */ }
  }
}
function hideIncoming() {
  state.incoming = null;
  $('#incoming').hidden = true;
  ring(false);
}

async function acceptCall() {
  const inc = state.incoming;
  if (!inc) return;
  hideIncoming();
  let stream;
  try {
    stream = await getMedia(inc.video);
  } catch {
    wsSend({ type: 'call', kind: 'reject', callId: inc.id });
    return toast('Нет доступа к микрофону. Разрешите его в настройках браузера');
  }
  state.call = { id: inc.id, peerId: inc.from.id, role: 'callee', localStream: stream, pending: [], phase: 'connecting', pc: null };
  makePC();
  showCallUI();
  wsSend({ type: 'call', kind: 'accept', callId: inc.id });
}
function declineCall() {
  const inc = state.incoming;
  if (!inc) return;
  wsSend({ type: 'call', kind: 'reject', callId: inc.id });
  hideIncoming();
}

async function onCallSignal(m) {
  const c = state.call;
  switch (m.kind) {
    case 'invite':
      if (state.call || state.incoming) {
        wsSend({ type: 'call', kind: 'reject', callId: m.callId });
        return;
      }
      showIncoming({ id: m.callId, from: m.from, video: m.video });
      break;
    case 'handled':
      if (state.incoming && state.incoming.id === m.callId) hideIncoming();
      break;
    case 'accept': // мы звонили — собеседник ответил
      if (!c || c.id !== m.callId) return;
      clearTimeout(c.ringTimer);
      c.phase = 'connecting';
      setCallStatus('Соединение…');
      try {
        const pc = makePC();
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        wsSend({ type: 'call', kind: 'offer', callId: c.id, data: { type: offer.type, sdp: offer.sdp } });
      } catch {
        hangup('Не удалось начать звонок');
      }
      break;
    case 'offer':
      if (!c || c.id !== m.callId || !c.pc) return;
      try {
        await c.pc.setRemoteDescription(m.data);
        await flushIce();
        const answer = await c.pc.createAnswer();
        await c.pc.setLocalDescription(answer);
        wsSend({ type: 'call', kind: 'answer', callId: c.id, data: { type: answer.type, sdp: answer.sdp } });
      } catch {
        hangup('Не удалось принять звонок');
      }
      break;
    case 'answer':
      if (!c || c.id !== m.callId || !c.pc) return;
      try {
        await c.pc.setRemoteDescription(m.data);
        await flushIce();
      } catch {
        hangup('Не удалось соединиться');
      }
      break;
    case 'ice':
      if (c && c.id === m.callId) addIce(m.data);
      break;
    case 'reject':
      if (c && c.id === m.callId) endCallLocal('Звонок отклонён');
      break;
    case 'busy':
      if (c && c.id === m.callId) endCallLocal('Абонент занят');
      break;
    case 'unavailable':
      if (c && c.id === m.callId) endCallLocal('Собеседник не в сети');
      break;
    case 'end':
      if (state.incoming && state.incoming.id === m.callId) {
        hideIncoming();
        toast('Пропущенный звонок');
      } else if (c && c.id === m.callId) {
        endCallLocal('Звонок завершён');
      }
      break;
    default:
  }
}

$('#call-audio').addEventListener('click', () => startCall(false));
$('#call-video').addEventListener('click', () => startCall(true));
$('#in-accept').addEventListener('click', acceptCall);
$('#in-decline').addEventListener('click', declineCall);
$('#btn-hang').addEventListener('click', () => hangup());
$('#btn-mute').addEventListener('click', () => {
  const c = state.call;
  if (!c) return;
  const tracks = c.localStream.getAudioTracks();
  const off = tracks.some((t) => t.enabled);
  tracks.forEach((t) => (t.enabled = !off));
  $('#btn-mute').classList.toggle('off', off);
});
$('#btn-cam').addEventListener('click', () => {
  const c = state.call;
  if (!c) return;
  const tracks = c.localStream.getVideoTracks();
  const off = tracks.some((t) => t.enabled);
  tracks.forEach((t) => (t.enabled = !off));
  $('#btn-cam').classList.toggle('off', off);
});
window.addEventListener('beforeunload', () => {
  if (state.call) wsSend({ type: 'call', kind: 'end', callId: state.call.id });
});

boot();
})();
