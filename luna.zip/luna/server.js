'use strict';
/**
 * Луна — сервер мессенджера.
 * Вход по коду из почты, личные чаты, статус «в сети», сигналинг для звонков (WebRTC).
 */
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const express = require('express');
const { WebSocketServer } = require('ws');
const Database = require('better-sqlite3');
const nodemailer = require('nodemailer');

const PORT = Number(process.env.PORT) || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'luna.db');

/* ───────────── База данных ───────────── */
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    username TEXT UNIQUE COLLATE NOCASE,
    name TEXT,
    created_at INTEGER NOT NULL,
    last_seen INTEGER
  );
  CREATE TABLE IF NOT EXISTS codes (
    email TEXT PRIMARY KEY,
    hash TEXT NOT NULL,
    expires INTEGER NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    sent_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_id INTEGER NOT NULL,
    to_id INTEGER NOT NULL,
    text TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    read_at INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_msg_pair ON messages (from_id, to_id, id);
  CREATE INDEX IF NOT EXISTS idx_msg_to ON messages (to_id, read_at);
`);

let SECRET = process.env.APP_SECRET;
if (!SECRET) {
  const row = db.prepare("SELECT v FROM meta WHERE k = 'secret'").get();
  if (row) SECRET = row.v;
  else {
    SECRET = crypto.randomBytes(32).toString('hex');
    db.prepare("INSERT INTO meta (k, v) VALUES ('secret', ?)").run(SECRET);
  }
}

/* ───────────── Утилиты ───────────── */
const now = () => Date.now();
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const hmac = (s) => crypto.createHmac('sha256', SECRET).update(s).digest('hex');
const safeEq = (a, b) => {
  const A = Buffer.from(a);
  const B = Buffer.from(b);
  return A.length === B.length && crypto.timingSafeEqual(A, B);
};

const buckets = new Map();
function limited(key, max, windowMs) {
  const t = now();
  let b = buckets.get(key);
  if (!b || b.reset < t) {
    b = { n: 0, reset: t + windowMs };
    buckets.set(key, b);
  }
  b.n++;
  return b.n > max;
}
setInterval(() => {
  const t = now();
  for (const [k, b] of buckets) if (b.reset < t) buckets.delete(k);
}, 60_000).unref();

function normEmail(v) {
  const e = String(v || '').trim().toLowerCase();
  if (e.length > 254 || !/^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/.test(e)) return null;
  return e;
}

const pub = (u) =>
  u && {
    id: u.id,
    username: u.username,
    name: u.name || u.username || 'Без имени',
    last_seen: u.last_seen || null,
  };
const meView = (u) => ({ ...pub(u), email: u.email });
const getUser = (id) => db.prepare('SELECT * FROM users WHERE id = ?').get(id);

/* ───────────── Почта ───────────── */
let transporter = null;
if (process.env.SMTP_HOST) {
  const port = Number(process.env.SMTP_PORT) || 465;
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: port === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
} else {
  console.warn('⚠️  SMTP не настроен: коды входа будут печататься только в консоль. Настройте SMTP_* в Secrets.');
}

async function sendCode(email, code) {
  if (!transporter) {
    console.log(`[DEV] Код для ${email}: ${code}`);
    return;
  }
  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject: `Луна: код входа ${code}`,
    text: `Ваш код для входа в Луну: ${code}\nОн действует 10 минут. Если вы не запрашивали код — просто проигнорируйте письмо.`,
    html: `<div style="font-family:system-ui,sans-serif;max-width:420px">
      <h2 style="margin:0 0 8px">🌙 Луна</h2>
      <p>Ваш код для входа:</p>
      <p style="font-size:32px;font-weight:700;letter-spacing:6px;margin:8px 0">${code}</p>
      <p style="color:#666">Код действует 10 минут. Если вы не запрашивали его — проигнорируйте письмо.</p>
    </div>`,
  });
}

/* ───────────── Онлайн-состояние ───────────── */
const online = new Map(); // userId -> Set<WebSocket>
const calls = new Map(); // callId -> { a, b, sockA, sockB, timer }

const send = (w, o) => {
  if (w && w.readyState === 1) w.send(JSON.stringify(o));
};
function push(uid, obj) {
  const set = online.get(uid);
  if (!set) return;
  const d = JSON.stringify(obj);
  for (const w of set) if (w.readyState === 1) w.send(d);
}
function peersOf(uid) {
  return db
    .prepare(
      'SELECT DISTINCT CASE WHEN from_id = ? THEN to_id ELSE from_id END AS p FROM messages WHERE from_id = ? OR to_id = ?'
    )
    .all(uid, uid, uid)
    .map((r) => r.p);
}
function broadcastPresence(uid, isOnline, lastSeen) {
  for (const p of peersOf(uid)) push(p, { type: 'presence', userId: uid, online: isOnline, last_seen: lastSeen });
}

/* ───────────── HTTP ───────────── */
const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(express.json({ limit: '20kb' }));
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy':
      "default-src 'self'; connect-src 'self' ws: wss:; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; script-src 'self'",
  });
  next();
});

app.get('/health', (req, res) => res.type('text').send('ok'));

function userByToken(tok) {
  if (!tok || typeof tok !== 'string' || tok.length > 128) return null;
  return db
    .prepare('SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?')
    .get(sha(tok));
}
function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const user = userByToken(h.startsWith('Bearer ') ? h.slice(7) : '');
  if (!user) return res.status(401).json({ error: 'Требуется вход' });
  req.user = user;
  req.token = h.slice(7);
  next();
}
function full(req, res, next) {
  if (!req.user.username) return res.status(403).json({ error: 'Завершите регистрацию' });
  next();
}

/* — Вход по коду — */
app.post('/api/auth/request', async (req, res) => {
  const email = normEmail(req.body && req.body.email);
  if (!email) return res.status(400).json({ error: 'Введите корректную почту' });
  if (limited('req:' + req.ip, 10, 3600_000))
    return res.status(429).json({ error: 'Слишком много попыток. Попробуйте позже' });
  const prev = db.prepare('SELECT sent_at FROM codes WHERE email = ?').get(email);
  if (prev && now() - prev.sent_at < 60_000)
    return res.status(429).json({ error: 'Код уже отправлен. Новый можно запросить через минуту' });

  const code = String(crypto.randomInt(100000, 1000000));
  db.prepare(
    `INSERT INTO codes (email, hash, expires, attempts, sent_at) VALUES (?, ?, ?, 0, ?)
     ON CONFLICT(email) DO UPDATE SET hash = excluded.hash, expires = excluded.expires, attempts = 0, sent_at = excluded.sent_at`
  ).run(email, hmac(email + ':' + code), now() + 10 * 60_000, now());
  try {
    await sendCode(email, code);
    res.json({ ok: true });
  } catch (e) {
    console.error('Ошибка отправки письма:', e.message);
    db.prepare('DELETE FROM codes WHERE email = ?').run(email);
    res.status(502).json({ error: 'Не удалось отправить письмо. Проверьте почту и попробуйте позже' });
  }
});

app.post('/api/auth/verify', (req, res) => {
  const email = normEmail(req.body && req.body.email);
  const code = String((req.body && req.body.code) || '').trim();
  if (!email || !/^\d{6}$/.test(code)) return res.status(400).json({ error: 'Введите 6-значный код' });
  if (limited('ver:' + req.ip, 30, 3600_000))
    return res.status(429).json({ error: 'Слишком много попыток. Попробуйте позже' });

  const row = db.prepare('SELECT * FROM codes WHERE email = ?').get(email);
  if (!row || row.expires < now()) return res.status(400).json({ error: 'Код истёк. Запросите новый' });
  if (row.attempts >= 5) {
    db.prepare('DELETE FROM codes WHERE email = ?').run(email);
    return res.status(429).json({ error: 'Слишком много неверных попыток. Запросите новый код' });
  }
  if (!safeEq(row.hash, hmac(email + ':' + code))) {
    db.prepare('UPDATE codes SET attempts = attempts + 1 WHERE email = ?').run(email);
    return res.status(400).json({ error: 'Неверный код' });
  }
  db.prepare('DELETE FROM codes WHERE email = ?').run(email);

  let u = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!u) {
    const r = db.prepare('INSERT INTO users (email, created_at) VALUES (?, ?)').run(email, now());
    u = getUser(r.lastInsertRowid);
  }
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions (token_hash, user_id, created_at) VALUES (?, ?, ?)').run(sha(token), u.id, now());
  db.prepare(
    'DELETE FROM sessions WHERE user_id = ? AND rowid NOT IN (SELECT rowid FROM sessions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10)'
  ).run(u.id, u.id);
  res.json({ token, user: meView(u) });
});

app.post('/api/auth/logout', auth, (req, res) => {
  db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha(req.token));
  res.json({ ok: true });
});

/* — Профиль и настройки — */
app.get('/api/me', auth, (req, res) => res.json(meView(req.user)));

app.get('/api/config', auth, (req, res) => {
  const iceServers = [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }];
  if (process.env.TURN_URLS) {
    iceServers.push({
      urls: process.env.TURN_URLS.split(',').map((s) => s.trim()).filter(Boolean),
      username: process.env.TURN_USER || '',
      credential: process.env.TURN_PASS || '',
    });
  }
  res.json({ iceServers });
});

app.post('/api/profile', auth, (req, res) => {
  const username = String((req.body && req.body.username) || '').trim().replace(/^@/, '');
  const name = String((req.body && req.body.name) || '').trim().slice(0, 40);
  if (!name) return res.status(400).json({ error: 'Введите имя' });
  if (!/^[A-Za-z][A-Za-z0-9_]{3,19}$/.test(username))
    return res.status(400).json({ error: 'Имя пользователя: 4–20 символов, латиница, цифры и _, первая — буква' });
  const taken = db.prepare('SELECT id FROM users WHERE username = ? AND id <> ?').get(username, req.user.id);
  if (taken) return res.status(409).json({ error: 'Это имя пользователя уже занято' });
  try {
    db.prepare('UPDATE users SET username = ?, name = ? WHERE id = ?').run(username, name, req.user.id);
  } catch {
    return res.status(409).json({ error: 'Это имя пользователя уже занято' });
  }
  res.json(meView(getUser(req.user.id)));
});

/* — Поиск, чаты, сообщения — */
app.get('/api/search', auth, full, (req, res) => {
  const q = String(req.query.q || '').trim().replace(/^@/, '');
  if (q.length < 2 || q.length > 20 || !/^[A-Za-z0-9_]+$/.test(q)) return res.json([]);
  const rows = db
    .prepare(
      "SELECT * FROM users WHERE username LIKE ? ESCAPE '\\' AND id <> ? AND username IS NOT NULL ORDER BY username LIMIT 20"
    )
    .all(q.replace(/_/g, '\\_') + '%', req.user.id);
  res.json(rows.map(pub));
});

app.get('/api/chats', auth, full, (req, res) => {
  const me = req.user.id;
  const rows = db
    .prepare(
      `SELECT peer, MAX(id) AS last_id, SUM(unread) AS unread FROM (
         SELECT CASE WHEN from_id = @me THEN to_id ELSE from_id END AS peer, id,
                CASE WHEN to_id = @me AND read_at IS NULL THEN 1 ELSE 0 END AS unread
         FROM messages WHERE from_id = @me OR to_id = @me
       ) GROUP BY peer ORDER BY last_id DESC LIMIT 200`
    )
    .all({ me });
  const getMsg = db.prepare('SELECT id, from_id, to_id, text, created_at, read_at FROM messages WHERE id = ?');
  res.json(
    rows.map((r) => ({
      user: pub(getUser(r.peer)),
      last: getMsg.get(r.last_id),
      unread: r.unread || 0,
      online: online.has(r.peer),
    }))
  );
});

function peerOr404(req, res) {
  const id = Number(req.params.peer);
  if (!Number.isInteger(id) || id === req.user.id) {
    res.status(400).json({ error: 'Неверный получатель' });
    return null;
  }
  const u = getUser(id);
  if (!u || !u.username) {
    res.status(404).json({ error: 'Пользователь не найден' });
    return null;
  }
  return u;
}

app.get('/api/messages/:peer', auth, full, (req, res) => {
  const peer = peerOr404(req, res);
  if (!peer) return;
  const me = req.user.id;
  const before = Number(req.query.before) || Number.MAX_SAFE_INTEGER;
  const rows = db
    .prepare(
      `SELECT id, from_id, to_id, text, created_at, read_at FROM messages
       WHERE ((from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)) AND id < ?
       ORDER BY id DESC LIMIT 50`
    )
    .all(me, peer.id, peer.id, me, before)
    .reverse();
  res.json({ messages: rows, peer: pub(peer), online: online.has(peer.id) });
});

app.post('/api/messages/:peer', auth, full, (req, res) => {
  const peer = peerOr404(req, res);
  if (!peer) return;
  const me = req.user.id;
  if (limited('msg:' + me, 30, 10_000)) return res.status(429).json({ error: 'Слишком быстро. Подождите немного' });
  const text = String((req.body && req.body.text) || '').trim();
  if (!text || text.length > 4000) return res.status(400).json({ error: 'Сообщение пустое или слишком длинное' });
  const t = now();
  const r = db.prepare('INSERT INTO messages (from_id, to_id, text, created_at) VALUES (?, ?, ?, ?)').run(me, peer.id, text, t);
  const message = { id: r.lastInsertRowid, from_id: me, to_id: peer.id, text, created_at: t, read_at: null };
  push(peer.id, { type: 'message', message, from: pub(req.user) });
  push(me, { type: 'message', message });
  res.json(message);
});

app.post('/api/read/:peer', auth, full, (req, res) => {
  const peer = peerOr404(req, res);
  if (!peer) return;
  const t = now();
  const r = db
    .prepare('UPDATE messages SET read_at = ? WHERE from_id = ? AND to_id = ? AND read_at IS NULL')
    .run(t, peer.id, req.user.id);
  if (r.changes) push(peer.id, { type: 'read', by: req.user.id, at: t });
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', (req, res) => res.status(404).json({ error: 'Не найдено' }));

/* ───────────── WebSocket: онлайн, «печатает», звонки ───────────── */
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 128 * 1024 });

const CALL_KINDS = new Set(['invite', 'accept', 'reject', 'end', 'offer', 'answer', 'ice']);
const inCall = (uid) => [...calls.values()].some((c) => c.a === uid || c.b === uid);

function dropCall(id, except) {
  const c = calls.get(id);
  if (!c) return;
  calls.delete(id);
  clearTimeout(c.timer);
  const note = { type: 'call', kind: 'end', callId: id };
  if (c.sockB) {
    if (c.sockB !== except) send(c.sockB, note);
  } else {
    for (const w of online.get(c.b) || []) if (w !== except) send(w, note);
  }
  if (c.sockA !== except) send(c.sockA, note);
}

function handleCall(ws, m) {
  const kind = m.kind;
  const id = String(m.callId || '');
  if (!CALL_KINDS.has(kind) || !/^[a-f0-9-]{8,64}$/i.test(id)) return;
  const me = ws.user.id;

  if (kind === 'invite') {
    const to = Number(m.to);
    if (calls.has(id)) return;
    if (!Number.isInteger(to) || to === me || !online.has(to))
      return send(ws, { type: 'call', kind: 'unavailable', callId: id });
    if (inCall(to) || inCall(me)) return send(ws, { type: 'call', kind: 'busy', callId: id });
    const call = { a: me, b: to, sockA: ws, sockB: null, timer: null };
    call.timer = setTimeout(() => dropCall(id), 60_000);
    calls.set(id, call);
    push(to, { type: 'call', kind: 'invite', callId: id, from: pub(ws.user), video: !!m.video });
    return;
  }

  const c = calls.get(id);
  if (!c) return;
  const isA = ws === c.sockA;
  const isB = !isA && c.b === me && (!c.sockB || ws === c.sockB);
  if (!isA && !isB) return;

  if (kind === 'accept') {
    if (!isB || c.sockB) return;
    c.sockB = ws;
    clearTimeout(c.timer);
    for (const w of online.get(c.b) || []) if (w !== ws) send(w, { type: 'call', kind: 'handled', callId: id });
    send(c.sockA, { type: 'call', kind: 'accept', callId: id });
    return;
  }
  if (kind === 'reject') {
    if (!isB || c.sockB) return;
    calls.delete(id);
    clearTimeout(c.timer);
    send(c.sockA, { type: 'call', kind: 'reject', callId: id });
    for (const w of online.get(c.b) || []) if (w !== ws) send(w, { type: 'call', kind: 'handled', callId: id });
    return;
  }
  if (kind === 'end') return dropCall(id, ws);

  // offer / answer / ice — просто пересылаем второй стороне
  const target = isA ? c.sockB : c.sockA;
  if (!target || m.data == null) return;
  send(target, { type: 'call', kind, callId: id, data: m.data });
}

wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.user = null;
  const authTimer = setTimeout(() => {
    if (!ws.user) ws.close(4001, 'auth timeout');
  }, 10_000);
  ws.on('pong', () => (ws.isAlive = true));

  ws.on('message', (raw) => {
    try {
      const m = JSON.parse(raw);
      if (!ws.user) {
        if (m.type !== 'auth') return;
        const u = userByToken(String(m.token || ''));
        if (!u || !u.username) {
          send(ws, { type: 'auth_error' });
          return ws.close(4003, 'unauthorized');
        }
        clearTimeout(authTimer);
        ws.user = u;
        let set = online.get(u.id);
        if (!set) online.set(u.id, (set = new Set()));
        set.add(ws);
        send(ws, { type: 'ready', online: peersOf(u.id).filter((p) => online.has(p)) });
        if (set.size === 1) broadcastPresence(u.id, true, null);
        return;
      }
      if (limited('ws:' + ws.user.id, 600, 60_000)) return;
      if (m.type === 'typing') {
        const to = Number(m.to);
        if (Number.isInteger(to) && !limited('typ:' + ws.user.id, 60, 60_000)) push(to, { type: 'typing', from: ws.user.id });
      } else if (m.type === 'call') {
        handleCall(ws, m);
      }
    } catch (e) {
      /* некорректное сообщение — игнорируем */
    }
  });

  ws.on('close', () => {
    clearTimeout(authTimer);
    if (!ws.user) return;
    const uid = ws.user.id;
    for (const [id, c] of [...calls]) if (c.sockA === ws || c.sockB === ws) dropCall(id, ws);
    const set = online.get(uid);
    if (set) {
      set.delete(ws);
      if (!set.size) {
        online.delete(uid);
        const t = now();
        db.prepare('UPDATE users SET last_seen = ? WHERE id = ?').run(t, uid);
        broadcastPresence(uid, false, t);
      }
    }
  });
});

// Пинг раз в 30 секунд: держит соединение живым за прокси и убирает «мёртвые» сокеты
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) {
      ws.terminate();
      continue;
    }
    ws.isAlive = false;
    ws.ping();
  }
}, 30_000).unref();

// Старые просроченные коды — раз в час
setInterval(() => db.prepare('DELETE FROM codes WHERE expires < ?').run(now()), 3600_000).unref();

server.listen(PORT, '0.0.0.0', () => console.log(`🌙 Луна запущена на порту ${PORT}`));
